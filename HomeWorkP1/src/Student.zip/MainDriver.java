/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author ayden
 */
public class MainDriver {
    public static void main(String[] args) {
        // Creating Course object and calling methods
        Course mathCourse = new Course("MATH101", "Mathematics", "4");
        mathCourse.displayCourseInfo();

        // Creating Student object, adding a course, and calling methods
        Student student = new Student();
        student.addCourse("CS101", "Computer Science", "3");
        student.addCourse("ENG201", "English", "3");
        student.displayStudentInfo();
        System.out.println("Total Credits: " + student.getTotalCredits());
    }
  
}
