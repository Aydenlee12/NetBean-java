/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

/**
 *
 * @author ayden
 */
public class MainDriver {
    public static void main(String[] args){
    Person p1 = new Person();
    Student s1 = new Student();
    Instructor i1 = new Instructor();
    
    p1.setName("Parent: Ayden");
    s1.setName("Student: Jesus");
    s1.setAge(19);
    s1.setMarks1(86.0);
    s1.setMarks2(91.5);
    s1.Displaydetail();
    
    }
}