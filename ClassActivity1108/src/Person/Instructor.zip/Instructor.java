/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

/**
 *
 * @author ayden
 */
public class Instructor extends Person {
    private double basicSalary;
    private String officeHour;
    
    public Instructor(){
     
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public String getOfficeHour() {
        return officeHour;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public void setOfficeHour(String officeHour) {
        this.officeHour = officeHour;
    }
    public void Displaydetail(){
        System.out.println(" ame: " + this.getName());
        System.out.println("Age: " + this.getAge());
        System.out.println("Basic Salary: " +this.basicSalary);
        System.out.println("Office hours: " +this.officeHour);
    }
    public double calcTotalSalary(){
         return (this.basicSalary + (this.basicSalary * 0.05)) + 100;
    }
}   
