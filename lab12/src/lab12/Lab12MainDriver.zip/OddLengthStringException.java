/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab12;

/**
 *
 * @author ayden
 */
public class OddLengthStringException extends Exception {
    public OddLengthStringException() {
        super("Error: Odd length string. Cannot divide into equal halves.");
    }
}
